<?php 



function ip()
{
    // Get real visitor IP behind CloudFlare network
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
              $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
              $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
    }
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}

function slug($title){
    $title = explode(" ", $title);
    $title = implode("-", $title);
    return $title;
  }
  
 function check_valid_url($url){
    $regex = "((https?|ftp)\:\/\/)?";
    $regex .= "([a-z0-9+!*(),;?&=\$_.-]+(\:[a-z0-9+!*(),;?&=\$_.-]+)?@)?";
    $regex .= "([a-z0-9-.]*)\.([a-z]{2,3})";
    $regex .= "(\:[0-9]{2,5})?";
    $regex .= "(\/([a-z0-9+\$_-]\.?)+)*\/?";
    $regex .= "(\?[a-z+&\$_.-][a-z0-9;:@&%=+\/\$_.-]*)?";
    $regex .= "(#[a-z_.-][a-z0-9+\$_.-]*)?";
    
    
    if (preg_match("/^$regex$/i", $url)) {
       return true;
    }else{
        return false;
    }
 }
 
 function toUrl($url){
    $url = explode("http://", $url);
    if(count($url) == 1){
        $url = $url[0];
    }else{
        $url = $url[1];
    }
    $url = explode("https://", $url);
    if(count($url) == 1){
        $url = $url[0];
    }else{
        $url = $url[1];
    }
    $url = explode("www.", $url);
    if(count($url) == 1){
        $url = $url[0];
    }else{
        $url = $url[1];
    }
    $url = "https://www." . $url;
    
    return $url;
 }
 
 function toName($url){
     $url = str_replace("http://", "", $url);
     $url = str_replace("https://", "", $url);
     $url = str_replace("www.", "", $url);
     $url = explode(".", $url);
     if(count($url) == 2){
         $url = $url[0];
     }elseif(count($url) == 3){
         $url = $url[0] . "." . $url[1];
     }elseif(count($url) == 4){
         $url = $url[0] . "." . $url[1] . "." . $url[2];
     }elseif(count($url) == 5){
         $url = $url[0] . "." . $url[1] . "." . $url[2] . "." .  $url[3];
     }elseif(count($url) == 6){
         $url = $url[0] . "." . $url[1] . "." . $url[2] . "." . $url[3] . "." . $url[4];
     }
     return $url;
 }
 
   function statusCode($url) {
    $handle = curl_init($url);
    curl_setopt($handle,  CURLOPT_RETURNTRANSFER, TRUE);
    $response = curl_exec($handle);
    $httpCode = curl_getinfo($handle, CURLINFO_HTTP_CODE);
    curl_close($handle);
    return $httpCode;         
  }  
  
  function getCrossing($service_id){
        $crossing_name = [];
        $crossings = \App\Models\CrossingSanctionsService::where("service_id", $service_id)->get();
        foreach($crossings as $crossing){
            $crossing_array = \App\Models\CrossingSanctions::find($crossing->crossing_id);
            unset($crossing_array->id);
            unset($crossing_array->created_at);
            unset($crossing_array->updated_at);
            unset($crossing_array->deleted_at);
    
            array_push($crossing_name, $crossing_array);
        }
        return $crossing_name;
  }
  
  function is403($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');    curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $html = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return (int)($code);
}
