<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Service;
use App\Models\CrossingSanctions;
use App\Models\CrossingSanctionsService;
use App\Models\NameService;


class FilterSearchController extends Controller
{
    public function index(){
        $url = $_GET['url'];
        $service = Service::where("url", toUrl($url))->get();

        if(count($service) != 0){
            $support = true;
            $sanction_status = true;
            $crossings_name = getCrossing($service[0]->id);
        }else{
            $support = false;
            $crossings_name = null;
            $http_code = is403($url);
            if($http_code == 0 || $http_code == 301 || $http_code == 200){
                $sanction_status = false;
            }else{
                $sanction_status = true;
            }
        }
       

        echo json_encode(["support" => $support, "sanction_status" => $sanction_status, "crossings" => $crossings_name]);
    }
}
