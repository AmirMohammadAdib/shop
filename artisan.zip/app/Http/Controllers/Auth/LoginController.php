<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Auth\LoginRequest;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Contracts\Session\Session;
use Illuminate\Support\Facades\Hash;


class LoginController extends Controller
{
    public function view()
    {
        return view("auth.login");
    }

    public function login(Request $request)
    {
        $inputs = $request->all();

        $user = User::where("email", $request->email)->get();

        if (!empty($user->all())) {
            $user = $user[0];
            if (Hash::check($request->password, $user->password)) {
                if ($user->status == 'enable') {
                    // auth()->attempt([
                    //     "email" => $inputs['email'],
                    //     "password" => $inputs['password'],
                    // ]);
                    $request->session()->push("user", $user->id);
                    return redirect("/dashboard")->with("swal-success", "ورود به پنل با موفقیت انجام شد:)");
                } else {
                    return back()->with("swal-warning", "حساب کاربری شما تایید نشده است");
                    exit;
                }
            } else {
                return back()->with("swal-error", "پسوورد وارد شده نامعتبر است");
            }
        } else {
            return back()->with("swal-warning", "ایمیل وارد شده در سایت وجود ندارد");
        }
    }
}
