<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Requests\AuthRequest;
use App\Mail\HelloMail;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use PDO;
use PDOException;
use App\Models\NormalUser;
use App\Models\UserPgSql;
use App\Models\CkeckManagment;


class AuthController
{
    public function register(){
        $code = rand(1000, 9999);
        $data = request()->validate([
            "email" => "email|required|unique:users,email",
            "name" => "required|unique:users,name",
            "password" => "required|min:6",
        ]);
        
        $data['confrim_code'] = $code;
        $data['password'] = Hash::make($data['password']);
        $user = User::create($data);
        
        //Mail::to('adib17362@gmail.com')->queue(new HelloMail($code));
        
        
        //$user = User::where("password", $data['password'])->first();
        //NormalUser::create(["User_id" => $user->id, "normal_username" => $user->name, "normal_password" => $user->password]);
        //UserPgSql::create(["User_id" => $user->id, "owner_id" => 0, "credit" => '1.00', "group_id" => 1, "creation_date" => $user->created_at]);
        
        return response()->json([
            'isSuccess' => true,
            "message" => "حساب کاربری با موفقیت ساخته شد",
            "result" => ["token" => $user->createToken("API Token")->plainTextToken],
            "statusCode" => 200,
        ]);
    }

    public function active(){
        $data = request()->validate([
            "email" => "email|required",
            "code" => "required",
        ]);

        $user = User::where("email", $data["email"])->where("confrim_code", $data['code'])->get();
        if(count($user) == 0){
            return response()->json([
                "isSuccess" => false,
                "message" => "حساب کاربری شما تایید نشده است",
                "result" => [],
                "statusCode" => 401,
            ], 401);
        }

        $user = $user[0];
        $user->email_verified_at = date("Y-m-d H:i:s");
        $user->status = "enable";
        
        return response()->json([
            'isSuccess' => true,
            "message" => "حساب کاربری با موفقیت تایید شد",
            "result" => ["token" => $user->createToken("API Token")->plainTextToken],
            "statusCode" => 200,
        ]);
    }

    public function login(){
        $data = request()->validate([
            "email" => "required",
            "password" => "required|min:6", 
            "name" => "", 
        ]);

        $data['name'] = $data['email'];

        if (filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            unset($data['name']);
        }else{
            unset($data['email']);
        }

        if(!Auth::attempt($data)){
            return response()->json([
                "isSuccess" => false,
                "message" => "ایمیل یا پسوورد وارد شده نامعتبر است",
                "result" => [],
                "statusCode" => 401,
            ], 401);
        }

        
        if(Auth::user()->status == "disable"){
            return response()->json([
                "isSuccess" => false,
                "message" => "حساب کاربری شما تایید نشده",
                "result" => [],
                "statusCode" => 401,
            ], 401);
        }
        
        $data = request()->validate([
            "device" => "",
        ]);
        
        if(empty($data)){
            $data['device'] = 0;
        }
        
        $token = Auth::user()->createToken("API Token")->plainTextToken;
        CkeckManagment::create(["token" => $token, "user_ip" => ip(), "status" => "login", "device" => $data['device']]);

        return response()->json([
            'isSuccess' => true,
            "statusCode" => 200,
            "message" => "ورود با موفقیت انجام شد",
            'result' => ["token" => $token],
        ]);
    }

    public function forgot(){
        $data = request()->validate([
            "email" => "email|required",
            "password" => "required|min:6",
            "new_password" => "required|min:6",
            "confirm_password" => "required|min:6",
        ]);

        if(!Auth::attempt($data)){
            return response()->json([
                "isSuccess" => false,
                "message" => "ایمیل یا پسوورد اشتباه است",
                "result" => [],
                "statusCode" => 401,
            ], 401);
        }

        if($data['new_password'] != $data['confirm_password']){
            return response()->json([
                "isSuccess" => false,
                "message" => "پسوورد های وارده با یکدیگر مغایرت دارد",
                "result" => [],
                "statusCode" => 401,
            ], 401);
        }

        $user = Auth::user();
        $user->password = Hash::make($data['new_password']);
        $user->save();

        return response()->json([
            'isSuccess' => true,
            "message" => "پسوورد با موفقیت تغییر یافت",
            "result" => ["token" => $user->createToken("API Token")->plainTextToken],
            "statusCode" => 200,
        ]);
    }
    
    public function logout(){
        $data = request()->validate([
            "token" => "required",
            "device" => "required",
        ]);
        
        $login = CkeckManagment::where("token", $data['token'])->get();
        if(count($login) == 0){
            return response()->json([
                "isSuccess" => false,
                "message" => "توکن وارد شده نامعتبر است",
                "result" => [],
                "statusCode" => 401,
            ], 401);
        }
        
        CkeckManagment::create(["token" => $data['token'], "user_ip" => ip(), "status" => "logout", "device" => $data['device']]);
        return response()->json([
            'isSuccess' => true,
            "message" => "خروج با موفقیت انجام شد",
            'result' => ["token" => $data['token']],
            "statusCode" => 200,
        ]);
    }
}
