<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Training;

class TrainingController extends Controller
{
    public function index(){
        if(session("user") == Null){
            return redirect("/login")->with("swal-info", "????? ???? ???? ??? ????");
            exit;
        }
      $trainings = Training::all();
      return view("admin.training.index", compact("trainings"));
    }
    
    public function create(){
        if(session("user") == Null){
            return redirect("/login")->with("swal-info", "????? ???? ???? ??? ????");
            exit;
        }
      $devices = ['Mac', 'Windows', 'Ios', 'Android', 'Linux', 'Router', 'play_station', 'xbox'];
      return view("admin.training.create", compact("devices"));
    }
    
    public function store(Request $request){
        if(session("user") == Null){
            return redirect("/login")->with("swal-info", "????? ???? ???? ??? ????");
            exit;
        }
      $past_training = Training::where("device",  $_POST['device'])->first();

      if(empty($past_training)){
        if($request->file("icon")){
        
          $file_name = time() . "." . $request->icon->extension();
          $request->icon->move(public_path("pictures/training-icon/"), $file_name);

          Training::create(['device' => $_POST['device'], 'icon' => "/public/pictures/training-icon/" . $file_name, "name" => "linux", "color" => "#fff"]);
          return redirect("/admin/training");
        }else{
          return back();
        }
      }else{
        return back();
      }
    }
    
    public function edit($id){
        if(session("user") == Null){
            return redirect("/login")->with("swal-info", "????? ???? ???? ??? ????");
            exit;
        }
      $training = Training::find($id);
      $devices = ['Mac', 'Windows', 'Ios', 'Android', 'Linux', 'Router', 'play_station', 'xbox'];
      return view("admin.training.edit", compact("training", "devices"));
    }
    
    public function update(Request $request, $id){
        if(session("user") == Null){
            return redirect("/login")->with("swal-info", "????? ???? ???? ??? ????");
            exit;
        }
 
      $past_training = Training::where("device",  $_POST['device'])->first();
      if(empty($past_training)){
        $training = Training::find($id);
         if($request->file("icon")){
            $file_name = time() . "." . $request->icon->extension();
            $request->icon->move(public_path("pictures/training-icon/"), $file_name);
          
           $training->icon = "/pictures/training-icon/" . $file_name;
         }
        $training->device = $_POST['device'];
        $training->save();
        return redirect("/admin/training");
      }else{
        return back();
      }
    }
        
    public function delete($id){
        if(session("user") == Null){
            return redirect("/login")->with("swal-info", "????? ???? ???? ??? ????");
            exit;
        }
      Training::find($id)->delete();
      return back();
    }
    
}
