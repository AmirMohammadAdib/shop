<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\AdminController;
use Illuminate\Http\Request;
use App\Models\Service;
use App\Models\CrossingSanctions;
use App\Models\Training;


class DashboardController
{
    public function index(){
        if (session("user") == Null) {
            return redirect("/login")->with("swal-info", "ابتدا وارد حساب خود شوید");
            exit;
        }

        $services = Service::all();
        $crossings = CrossingSanctions::all();
        $trainings = Training::all();
        return view("admin.dashboard.index", compact("services", "crossings", "trainings"));
    }
}
