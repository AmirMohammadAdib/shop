<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Auth\LogoutController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\ServiceController;
use App\Http\Controllers\Admin\CrossingController;
use App\Http\Controllers\Admin\CrossingServiceController;
use App\Http\Controllers\Admin\TrainingController;
use App\Http\Controllers\Admin\ContentTrainingController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', function () {
    dd("Hi");
});


//authentication
Route::get("/login", [LoginController::class, "view"]);
Route::post("/login", [LoginController::class, "login"]);
Route::get("/register", [RegisterController::class, "view"]);
Route::post("/register", [RegisterController::class, "register"]);
Route::get("/logout", [LogoutController::class, "view"]);

//dashboard
Route::get("/admin", [AdminController::class, "index"]);
Route::get("/dashboard", [DashboardController::class, "index"]);

//services
Route::get("/admin/service", [ServiceController::class, "index"]);
Route::get("/admin/service/create", [ServiceController::class, "create"])->name("service.create");
Route::post("/admin/service/store", [ServiceController::class, "store"])->name("service.store");;
Route::get("/admin/service/edit/{id}", [ServiceController::class, "edit"])->name("service.edit");
Route::post("/admin/service/update/{id}", [ServiceController::class, "update"])->name("service.update");
Route::get("/admin/service/delete/{id}", [ServiceController::class, "delete"])->name("service.delete");
Route::get("/admin/name-service/create/{service_id}", [ServiceController::class, "nameService"])->name("service.name");
Route::post("/admin/name-service/store/{service_id}", [ServiceController::class, "nameServiceStore"])->name("service.name.store");

//crossing
Route::get("/admin/crossing", [CrossingController::class, "index"]);
Route::get("/admin/crossing/create", [CrossingController::class, "create"])->name("crossing.create");
Route::post("/admin/crossing/store", [CrossingController::class, "store"])->name("crossing.store");;
Route::get("/admin/crossing/edit/{id}", [CrossingController::class, "edit"])->name("crossing.edit");
Route::post("/admin/crossing/update/{id}", [CrossingController::class, "update"])->name("crossing.update");
Route::get("/admin/crossing/delete/{id}", [CrossingController::class, "delete"])->name("crossing.delete");


//crossing-services
Route::get("/admin/crossing-service/{service_id}", [CrossingServiceController::class, "index"])->name("crossing.service.index");;
Route::get("/admin/crossing-service/create/{service_id}", [CrossingServiceController::class, "create"])->name("crossing.service.create");
Route::post("/admin/crossing-service/store/{service_id}", [CrossingServiceController::class, "store"])->name("crossing.service.store");;
Route::get("/admin/crossing-service/edit/{id}", [CrossingServiceController::class, "edit"])->name("crossing.service.edit");
Route::post("/admin/crossing-service/update/{id}", [CrossingServiceController::class, "update"])->name("crossing.service.update");
Route::get("/admin/crossing-service/delete/{id}", [CrossingServiceController::class, "delete"])->name("crossing.service.delete");


//training
Route::get("/admin/training", [TrainingController::class, "index"])->name("training.index");
Route::get("/admin/training/create", [TrainingController::class, "create"])->name("training.create");
Route::post("/admin/training/store", [TrainingController::class, "store"])->name("training.store");
Route::get("/admin/training/edit/{id}", [TrainingController::class, "edit"])->name("training.edit");
Route::post("/admin/training/update/{id}", [TrainingController::class, "update"])->name("training.update");
Route::get("/admin/training/delete/{id}", [TrainingController::class, "delete"])->name("training.delete");

//training-content
Route::get("/admin/training-content/{training_id}", [ContentTrainingController::class, "index"])->name("training.content.index");
Route::get("/admin/training-content/create/{training_id}", [ContentTrainingController::class, "create"])->name("training.content.create");
Route::post("/admin/training-content/store/{training_id}", [ContentTrainingController::class, "store"])->name("training.content.store");
Route::get("/admin/training-content/edit/{id}", [ContentTrainingController::class, "edit"])->name("training.content.edit");
Route::post("/admin/training-content/update/{id}", [ContentTrainingController::class, "update"])->name("training.content.update");
Route::get("/admin/training-content/delete/{id}", [ContentTrainingController::class, "delete"])->name("training.content.delete");


Route::get('/terminal', function () {
    \Artisan::call('config:cache');
    return \Artisan::output();
});