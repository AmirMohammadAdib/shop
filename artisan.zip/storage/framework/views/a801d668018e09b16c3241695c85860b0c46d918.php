

<?php $__env->startSection('title'); ?>
    <title>Trainings - Didban</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
    <script src="//cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section_name'); ?>
    Trainings
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="added_ping">
        <a href="<?php echo e(route("training.create")); ?>">
            <button>
                add Training
            </button>
        </a>
    </div><br>
    <table id="table_id" class="display">
        <thead>
            <tr>
                <th>#</th>
                <th>Device</th>
                <th>Icon</th>
                <th>Count Of Subset Page</th>
                <th>Settings</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($training->id); ?></td>
                    <td><?php echo e($training->device); ?></td>
                    <td><img width="220" src="<?php echo e(asset($training->icon)); ?>"></td>
                    <td><?php echo e(count(\App\Models\TrainingContent::where("training_id", $training->id)->get())); ?></td>
                    <th>
                        <a href="<?php echo e(route("training.edit", [$training->id])); ?>" class="update">
                            <button>Update</button>
                        </a>
                        <a href="<?php echo e(route("training.delete", [$training->id])); ?>" class="remove">
                            <button>Delete</button>
                        </a>
                        <a href="<?php echo e(route("training.content.index", [$training->id])); ?>" class="update">
                            <button>Add Page</button>
                        </a>
                    </th>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
        <script>
        $(document).ready(function() {
            $('#table_id').DataTable();
        });
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/plusir/public_html/resources/views/admin/training/index.blade.php ENDPATH**/ ?>