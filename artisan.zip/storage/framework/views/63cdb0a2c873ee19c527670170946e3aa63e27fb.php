

<?php $__env->startSection('title'); ?>
    ثبت نام - 403
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-login">
        <h1 id="header_title_login">آزاد از تحریم ها</h1>
        <div class="login-box">
            <div class="poster-login">
                <i class="fa-sharp fa-solid fa-circle"></i>
                <span></span>
            </div>
            <div class="fields-login">
                <div class="head-login">
                    <h1>خوشحالیم که مارو انتخاب کردید:)</h1>
                    <p>خوش اومدی رفیق! لطفا اطلاعاتت رو وارد کن</p>
                </div><br>
                <div class="datalis">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <label for="">نام</label><br>
                        <input type="text" name="first_name" placeholder="لطفا نام خود را وارد کنید"><br><br>
                        <label for="">نام خانوادگی</label><br>
                        <input type="text" name="last_name" placeholder="لطفا نام خانوادگی خود را وارد کنید"><br><br>
                        <label for="">ایمیل</label><br>
                        <input type="email" name="email" placeholder="لطفا ایمیل خود را وارد کنید"><br><br>
                        <label for="">پسوورد</label><br>
                        <input type="password" name="password" placeholder="لطفا پسوورد خود را وارد کنید"><br><br><br>
                        <input type="submit" value="ثبت نام">
                    </form>
                    <p id="make_account">حساب کاربری داری؟ <a href="<?= url("/login") ?>">ورود</a></p>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make("alerts.error", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("alerts.warning", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("alerts.info", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developer\Desktop\403\resources\views/auth/register.blade.php ENDPATH**/ ?>