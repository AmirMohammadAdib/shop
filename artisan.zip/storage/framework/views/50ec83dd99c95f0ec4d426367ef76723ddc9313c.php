<?php if(session('swal-confrim-success')): ?>
    <script>
        $(document).ready(function() {
            Swal.fire(
                '<?php echo e(explode("@", session('swal-confrim-success'))[0]); ?>',
                '<?php echo e(explode("@", session('swal-confrim-success'))[1]); ?>',
                'success'
            )
        })
    </script>
<?php endif; ?>
<?php /**PATH C:\Users\developer\Desktop\403\resources\views/alerts/confrim-success.blade.php ENDPATH**/ ?>