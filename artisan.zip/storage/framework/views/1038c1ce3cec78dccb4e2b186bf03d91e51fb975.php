<h1>Your code: <?php echo e($code); ?></h1>
<h5>Welcome to the 403</h5><?php /**PATH /home/plusir/public_html/resources/views/mail/code.blade.php ENDPATH**/ ?>