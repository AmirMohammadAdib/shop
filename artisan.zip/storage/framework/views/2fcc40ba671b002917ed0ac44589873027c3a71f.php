

<?php $__env->startSection('title'); ?>
    <title>403 - سامانه دور زدن تحریم های تجاری</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section_name'); ?>
    پنل مدیریت
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="dashboard">
        
        <div class="box-dashboard" style="margin-bottom: 20px">
            <h3>سرویس های موجود</h3>
            <div class="added_item">
                <a href="<?php echo e(url("/admin/game/create")); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-plus"
                        viewBox="0 0 16 16">
                        <path
                            d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                    </svg>
                    <p>افزودن سرویس</p>
                </a>
            </div>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="game" style="background-image: url(<?php echo e($service->picture); ?>)"
                    style="height: auto; padding: 20px;" id="dashboard_game">
                    <h2><?php echo e($service->name); ?></h2>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <div class="box-dashboard" style="margin-bottom: 20px">
            <h3>مسیر های دور زدن تحریم</h3>
            <div class="added_item">
                <a href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-plus"
                        viewBox="0 0 16 16">
                        <path
                            d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                    </svg>
                    <p>افزودن مسیر</p>
                </a>
            </div>
            <?php $__currentLoopData = $crossings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crossing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="game"
                    style="background-image: url(); padding: 0; height: 100px; margin-bottom: 20px;"
                    id="dashboard_game">
                    <div class="ping-dashbord">
                        <p>
                           <?php echo e($crossing->name); ?>

                        </p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <div class="box-dashboard" id="every_ip" style="width: 100%">
            <div class="added_item">
                <a href="">
                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-plus"
                        viewBox="0 0 16 16">
                        <path
                            d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                    </svg>
                    <p>افزودن آموزش</p>
                </a>
            </div>
            <h3>لیست تمامی آموزش های موجود</h3>
            <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="game" style="background-color: rgba(51, 51, 51, 0.745); height: 80px; justify-content: space-around;"
                    id="every_ip_box">
                    <div>
                        <h6>آموزش دستگاه</h6>
                        <p style="text-align: center; font-size: 25px; font-family: 'kalameh_light'; color: var(--white);"><?php echo e($training->name); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/plusir/public_html/resources/views/admin/dashboard/index.blade.php ENDPATH**/ ?>