

<?php $__env->startSection('title'); ?>
    ورود - 403
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-login">
        <h1 id="header_title_login">آزاد از تحریم ها</h1>
        <div class="login-box">
            <div class="poster-login">
                <i class="fa-sharp fa-solid fa-circle"></i>
                <span></span>
            </div>
            <div class="fields-login">
                <div class="head-login">
                    <h1>خوش برگشتی</h1>
                    <p>خوش اومدی رفیق! لطفا اطلاعاتت رو وارد کن</p>
                </div><br>
                <div class="datalis">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <label for="">ایمیل</label><br>
                        <input type="email" name="email" placeholder="لطفا ایمیل خود را وارد کنید"><br><br>
                        <label for="">پسوورد</label><br>
                        <input type="password" name="password" placeholder="لطفا پسوورد خود را وارد کنید"><br><br><br>
                        <input type="submit" value="ورود">
                    </form>
                    <p id="make_account">حساب کاربری نداری؟ <a href="<?= url("/register") ?>">ثبت نام</a></p>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make("alerts.error", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("alerts.warning", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("alerts.info", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("alerts.confrim-success", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developer\Desktop\403\resources\views/auth/login.blade.php ENDPATH**/ ?>