<?php if(session('swal-info')): ?>
    <script>
        $(document).ready(function() {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })

            Toast.fire({
                icon: 'info',
                title: '<?php echo e(session("swal-info")); ?>'
            })
        })
    </script>
<?php endif; ?>
<?php /**PATH /home/plusir/public_html/resources/views/alerts/info.blade.php ENDPATH**/ ?>