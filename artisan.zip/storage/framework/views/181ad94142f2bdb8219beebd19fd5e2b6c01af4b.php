

<?php $__env->startSection('title'); ?>
    <title>Trainings Content - Didban</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
    <script src="//cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section_name'); ?>
    Trainings Content
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="added_ping">
        <a href="<?php echo e(route("training.content.create", [$training_id])); ?>">
            <button>
                add Training Content
            </button>
        </a>
    </div><br>
    <table id="table_id" class="display">
        <thead>
            <tr>
                <th>#</th>
                <th>Text</th>
                <th>Picture</th>
                <th>Training</th>
                <th>Current Page</th>
                <th>Type</th>
                <th>Settings</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($content->id); ?></td>
                    <td><?php echo e($content->text); ?></td>
                    <td><img width="200" src="<?php echo e(asset($content->picture)); ?>" /></td>
                    <td><?php echo e(\App\Models\Training::find($content->training_id)->device); ?></td>
                    <td><?php echo e($content->current_page); ?></td>
                    <td><?php echo e($content->type); ?></td>
                    <th>
                        <a href="<?php echo e(route("training.content.edit", [$content->id])); ?>" class="update">
                            <button>Update</button>
                        </a>
                        <a href="<?php echo e(route("training.content.delete", [$content->id])); ?>" class="remove">
                            <button>Delete</button>
                        </a>
                    </th>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
        <script>
        $(document).ready(function() {
            $('#table_id').DataTable();
        });
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/plusir/public_html/resources/views/admin/content-training/index.blade.php ENDPATH**/ ?>