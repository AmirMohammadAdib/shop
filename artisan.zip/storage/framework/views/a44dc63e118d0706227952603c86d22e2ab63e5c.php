<?php if(session('swal-error')): ?>
    <script>
        $(document).ready(function() {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })

            Toast.fire({
                icon: 'error',
                title: '<?php echo e(session("swal-error")); ?>'
            })
        })
    </script>
<?php endif; ?>
<?php /**PATH C:\Users\developer\Desktop\403\resources\views/alerts/error.blade.php ENDPATH**/ ?>