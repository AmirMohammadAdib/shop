


<?php $__env->startSection('title'); ?>
    <title>Training Content Create - Didban</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('section_name'); ?>
    Training Content Create
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route("training.content.store", [$training_id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="lists" style="flex-direction: column">
            <div class="ping-blocks">
                <div class="item-ping">
                    <label for="">Please Write Text</label>
                    <textarea name="text" placeholder="Text"></textarea>
                </div>
                <div class="item-ping">
                    <label for="">Please Upload Picture</label>
                    <input type="file" name="picture">
                </div>
            </div>
            <div class="ping-blocks">
                <div class="item-ping" style="width: 100%">
                    <label for="">Please Choose Type</label>
                    <select name="type">
                      <option value="dns">dns</option>
                      <option value="Ping reduction service">Ping reduction service</option>
                    </select>
                </div>
            </div>
        </div>
        <br>
        <input type="submit" value="add" id="add_ping">

    </form>


    <?php echo $__env->make("alerts.warning", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("alerts.success", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/plusir/public_html/resources/views/admin/content-training/create.blade.php ENDPATH**/ ?>