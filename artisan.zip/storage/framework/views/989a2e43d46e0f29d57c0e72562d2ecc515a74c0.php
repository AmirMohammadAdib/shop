


<?php $__env->startSection('title'); ?>
    <title>Create Training - Didban</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('section_name'); ?>
    Create Training
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route("training.store")); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="lists" style="flex-direction: column">
            <div class="ping-blocks">
                <div class="item-ping">
                    <label for="">Please Choose device</label>
                    <select name="device">
                      <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($device); ?>"><?php echo e($device); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="item-ping">
                    <label for="">Please Upload Icon</label>
                    <input type="file" name="icon">
                </div>
            </div>
        </div>
        <br>
        <input type="submit" value="add" id="add_ping">

    </form>


    <?php echo $__env->make("alerts.warning", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("alerts.success", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/plusir/public_html/resources/views/admin/training/create.blade.php ENDPATH**/ ?>