

<?php $__env->startSection('section_name'); ?>
    بخش سرویس
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
    <script src="//cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="added_ping">
        <a href="<?php echo e(route('service.create')); ?>">
            <button>
                افزودن سرویس
            </button>
        </a>
    </div><br>
    <table id="table_id" class="display">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Picture</th>
                <th>Special Level</th>
                <th>Crossing</th>
                <th>Settings</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($service->id); ?></td>
                    <td><?php echo e($service->name); ?></td>
                    <td><img src="<?php echo e($service->picture); ?>" width="100"></td>
                    <td><?php echo e($service->special_picture); ?></td>
                    <td>#</td>
                    <td>
                        <a href="<?php echo e(route('service.edit', [$service->id])); ?>" class="update">
                            <button>Update</button>
                        </a>
                        <a href="<?php echo e(route('service.delete', [$service->id])); ?>" class="remove">
                            <button>Delete</button>
                        </a>
                        <a href="<?php echo e(route('crossing.service.index', [$service->id])); ?>" class="update">
                            <button>Add Crossing</button>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <script>
        $(document).ready(function() {
            $('#table_id').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developer\Desktop\403\resources\views/admin/service/index.blade.php ENDPATH**/ ?>