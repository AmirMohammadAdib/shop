

<?php $__env->startSection('section_name'); ?>
    بخش عبور از تحریم
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
    <script src="//cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="added_ping">
        <a href="<?php echo e(route('crossing.service.create', [$id])); ?>">
            <button>
                افزودن راه عبور از تحریم
            </button>
        </a>
    </div><br>
    <table id="table_id" class="display">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Settings</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $crossings_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crossings_service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($crossings_service->id); ?></td>
                    <td><?php echo e(\App\Models\CrossingSanctions::find($crossings_service->crossing_id)->name); ?></td>
                    <td>
                        <a href="<?php echo e(route('crossing.service.edit', [$crossings_service->id])); ?>" class="update">
                            <button>Update</button>
                        </a>
                        <a href="<?php echo e(route('crossing.service.delete', [$crossings_service->id])); ?>" class="remove">
                            <button>Delete</button>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <script>
        $(document).ready(function() {
            $('#table_id').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/plusir/public_html/resources/views/admin/crossing-service/index.blade.php ENDPATH**/ ?>