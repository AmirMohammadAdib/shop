


<?php $__env->startSection('title'); ?>
    <title>403 - افزودن سرویس</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('section_name'); ?>
    بخش افزودن سرویس
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route("service.store")); ?>" method="POST" enctype="multipart/form-data" style="border: 1px solid rgba(89, 88, 88, 0.785); padding: 20px; border-radius: 10px;">
        <?php echo csrf_field(); ?>
        <div class="lists" style="flex-direction: column">
            <div class="ping-blocks">
                <div class="item-ping">
                    <label for="">نام سرویس</label>
                    <input type="text" placeholder="نام سرویس" name="name">
                </div>
                <div class="item-ping">
                    <label for="">تصویر سرویس</label>
                    <input type="file" placeholder="تصویر سرویس" name="picture">
                </div>
            </div>
            <div class="ping-blocks">
                <div class="item-ping" style="width: 100%">
                    <label for="">اختصاصی باشد؟</label>
                    <select name="special_level">
                        <option value="1">حتما</option>
                        <option value="0">نیازی نیست</option>
                    </select>
                </div>
            </div>
        </div>
        <br>
        <input type="submit" value="افزودن" id="add_ping">

    </form>

    <?php echo $__env->make("alerts.warning", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("alerts.success", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developer\Desktop\403\resources\views/admin/service/create.blade.php ENDPATH**/ ?>