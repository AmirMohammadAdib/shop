<?php if(session('swal-warning')): ?>
    <script>
        $(document).ready(function() {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })

            Toast.fire({
                icon: 'warning',
                title: '<?php echo e(session("swal-warning")); ?>'
            })
        })
    </script>
<?php endif; ?>
<?php /**PATH /home/plusir/public_html/resources/views/alerts/warning.blade.php ENDPATH**/ ?>