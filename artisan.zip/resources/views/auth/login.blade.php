@extends('auth.layouts.app')

@section('title')
    ورود - 403
@endsection

@section('content')
    <div class="container-login">
        <h1 id="header_title_login">آزاد از تحریم ها</h1>
        <div class="login-box">
            <div class="poster-login">
                <i class="fa-sharp fa-solid fa-circle"></i>
                <span></span>
            </div>
            <div class="fields-login">
                <div class="head-login">
                    <h1>خوش برگشتی</h1>
                    <p>خوش اومدی رفیق! لطفا اطلاعاتت رو وارد کن</p>
                </div><br>
                <div class="datalis">
                    <form action="" method="post">
                        @csrf
                        <label for="">ایمیل</label><br>
                        <input type="email" name="email" placeholder="لطفا ایمیل خود را وارد کنید"><br><br>
                        <label for="">پسوورد</label><br>
                        <input type="password" name="password" placeholder="لطفا پسوورد خود را وارد کنید"><br><br><br>
                        <input type="submit" value="ورود">
                    </form>
                    <p id="make_account">حساب کاربری نداری؟ <a href="<?= url("/register") ?>">ثبت نام</a></p>
                </div>
            </div>
        </div>
    </div>
    @include("alerts.error")
    @include("alerts.warning")
    @include("alerts.info")
    @include("alerts.confrim-success")

@endsection
