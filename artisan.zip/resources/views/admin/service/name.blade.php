@extends('admin.layouts.app')


@section('title')
    <title>403 - افزودن نام</title>
@endsection


@section('section_name')
    بخش افزودن نام
@endsection


@section('content')
    <form action="{{ route("service.name.store", [$id]) }}" method="POST" style="border: 1px solid rgba(89, 88, 88, 0.785); padding: 20px; border-radius: 10px;">
        @csrf
        <div class="lists" style="flex-direction: column">
            <div class="ping-blocks">
                <div class="item-ping" style="width: 100%">
                    <label for="">نام سرویس</label>
                    <input type="text" placeholder="نام سرویس" name="name">
                </div>
            </div>
        </div>
        <br>
        <input type="submit" value="افزودن" id="add_ping">

    </form>

    @include("alerts.warning")
    @include("alerts.success")

@endsection
